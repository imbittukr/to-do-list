<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>
    <div class="container mt-5">
        <h3>PHP - Simple To Do List App</h3>
        <div class="input-group mb-3">
            <input type="text" id="task" class="form-control" placeholder="Add Task">
            <button class="btn btn-primary" id="addTask">Add Task</button>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Task</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="taskList">
                @foreach($tasks as $key=>$task)
                    <tr data-id="{{ $task->id }}">
                    @php  
                    $key = $key + 1;
                    @endphp
                        <td>{{ $key}}</td>
                        <td>{{ $task->task }}</td>
                        <td>{{ $task->is_completed ? 'Done' : '' }}</td>
                        <td>
                       @if($task->is_completed != 1) 
                            <button class="btn btn-success completeTask">
                            <i class="fa fa-check-square-o" aria-hidden="true"></i>
                            </button>
                            @endif
                            <button class="btn btn-danger deleteTask"><i class="fa fa-times" aria-hidden="true"></i></button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
     $(document).ready(function() {
    // Add Task
    $('#addTask').on('click', function() {
        let task = $('#task').val();
        if (task === '') return;

        $.ajax({
            url: '/task',
            method: 'POST',
            data: { task: task },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                // Clear input field
                $('#task').val('');

                // Add new task row dynamically to the table
                $('#taskList').append(`
                    <tr data-id="${response.task.id}">
                        <td>${$('#taskList tr').length + 1}</td>
                        <td>${response.task.task}</td>
                        <td></td>
                        <td>
                            <button class="btn btn-success completeTask">
                                <i class="fa fa-check-square-o" aria-hidden="true"></i>
                            </button>
                            <button class="btn btn-danger deleteTask"><i class="fa fa-times" aria-hidden="true"></i></button>
                        </td>
                    </tr>
                `);
            }
        });
    });

    // Complete Task (Event Delegation)
    $('#taskList').on('click', '.completeTask', function() {
        let id = $(this).closest('tr').data('id');

        $.ajax({
            url: '/task/' + id,
            method: 'PUT',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                // Mark the task as completed (you can update the row accordingly)
                let row = $('tr[data-id="' + id + '"]');
                row.find('td:nth-child(3)').text('Done');
                row.find('.completeTask').remove(); // Remove the complete button
            }
        });
    });

    // Delete Task (Event Delegation)
    $('#taskList').on('click', '.deleteTask', function() {
        if (!confirm('Are you sure to delete this task?')) return;

        let id = $(this).closest('tr').data('id');

        $.ajax({
            url: '/task/' + id,
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                // Remove the task row from the table
                $('tr[data-id="' + id + '"]').remove();
            }
        });
    });
});

    </script>
</body>
</html>