<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = Task::all();
        return view('tasks.index', compact('tasks'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'task' => 'required|unique:tasks,task',
        ]);
    
        $task = Task::create([
            'task' => $request->task,
        ]);
    
        return response()->json(['task' => $task, 'success' => 'Task added successfully']);
    }

    public function update($id)
    {
        $task = Task::findOrFail($id);
        $task->is_completed = !$task->is_completed;
        $task->save();
    
        return response()->json(['success' => 'Task status updated successfully', 'task' => $task]);
    }

    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $task->delete();
    
        return response()->json(['success' => 'Task deleted successfully']);
    }
    
}
